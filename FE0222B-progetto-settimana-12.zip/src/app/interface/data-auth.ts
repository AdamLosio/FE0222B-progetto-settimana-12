export interface DataAuth {
  accessToken:string,
  user:{
    id:number,
    emial:string,
    name:string,
    surname:string
  }
}

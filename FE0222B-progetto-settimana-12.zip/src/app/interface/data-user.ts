export interface DataUser {
  username:string,
  email:string,
  password:string
}

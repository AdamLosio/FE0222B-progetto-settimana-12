import { Component, OnInit } from '@angular/core';
import { tap } from 'rxjs';
import { AuthService } from 'src/app/auth/auth-service.service';
import { Movies } from 'src/app/interface/movies';

@Component({
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(private MoviesSrv: AuthService) { }

arrayMovies:Movies[]=[]

  ngOnInit(): void {
    this.MoviesSrv.takeFilms().pipe(tap((movies)=>{
      this.arrayMovies=movies
    }))
  }

}

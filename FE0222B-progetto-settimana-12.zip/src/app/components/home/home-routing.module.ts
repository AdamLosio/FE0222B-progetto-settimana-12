import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/auth/auth-guard.guard';
import { HomeComponent } from './home.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [
  {
  path: '',
  component:HomeComponent,
  canActivate:[AuthGuard]
}
];



@NgModule({
  declarations:[
    HomeComponent
  ],
  imports: [
    RouterModule.forChild(routes),
CommonModule
  ],
  exports:[RouterModule]
})
export class HomeRoutingModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfiloRoutingModule } from './profilo-routing.module';
import { ProfiloComponent } from './profilo.component';



@NgModule({
  declarations: [
  ],
  imports: [
    CommonModule,
    ProfiloRoutingModule
  ]
})
export class ProfiloModule { }
